class A{
    int i;
    String e;
    int a;
    String f;
    int b;
    String g;
    int c;
    String h;
}